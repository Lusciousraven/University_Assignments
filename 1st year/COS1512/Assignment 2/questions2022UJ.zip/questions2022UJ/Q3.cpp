
#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <cstring>
using namespace std;

int main() {
    vector<string> boys;
    vector<string> boyss;
    vector<string> girlss;
    ifstream fin("BabyNames.dat");
    string num;
    int icount =0;
    
    
    while (fin >> num)
        boys.push_back(num);

    
    for(int i=0;i<boys.size();i++){
        if(i%2 != 0){
            girlss.push_back(boys[i]);
        }else{
            boyss.push_back(boys[i]);
        }
    }

    string BorG;
    string prefix;
    cout << "boy or girl" << endl;
    cin  >>BorG;
    cout << "Prefix please" << endl;
    cin >> prefix;
    if(BorG =="boy"){
        for(int b=0;b<boyss.size();b++){
            if(boyss[b].rfind(prefix,0) == 0){
                cout << boyss[b] << endl;
            }
        }
    }else{
        for(int g=0;g<girlss.size();g++){
            if(girlss[g].rfind(prefix,0) == 0){
                cout << girlss[g] << endl;
            }
        }
    }
    
    
    return 0;
}