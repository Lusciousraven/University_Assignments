
#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <cstring>
using namespace std;

int main() {

string str;

// Read from the text file
ifstream MyReadFile("question4inpfile.txt");

//write to file
ofstream Myfile("question4outfile.txt");

while (getline (MyReadFile, str)) {
  string nstr;
  for(int i=0; i<str.length();  ){

        if(str[i] == ' '){

            if(i==0 || i==str.length()-1){
                i++;
                continue;
            }

            while(str[i+1] == ' ')
                i++;
        }
        
        nstr += str[i++];
    }
    Myfile << nstr;
  
}

// Close the file
MyReadFile.close();
Myfile.close();
    return 0;
}